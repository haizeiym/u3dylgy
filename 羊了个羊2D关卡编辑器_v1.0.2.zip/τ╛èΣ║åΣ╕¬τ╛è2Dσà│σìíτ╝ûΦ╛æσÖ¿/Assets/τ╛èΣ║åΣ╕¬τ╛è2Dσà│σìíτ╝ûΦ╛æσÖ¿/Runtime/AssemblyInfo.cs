using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("羊了个羊2D关卡编辑器.Editor")] 