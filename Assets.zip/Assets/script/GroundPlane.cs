using UnityEngine;

public class GroundPlane : MonoBehaviour
{
    [Header("地面设置")]
    public Vector2 gridSize = new Vector2(8, 8);
    public float cardSpacing = 1.2f;
    public Material groundMaterial;
    public Material gridMaterial;
    
    private GameObject groundPlane;
    private GameObject gridLines;
    
    void Start()
    {
        CreateGroundPlane();
        CreateGridLines();
    }
    
    void CreateGroundPlane()
    {
        groundPlane = GameObject.CreatePrimitive(PrimitiveType.Plane);
        groundPlane.name = "GroundPlane";
        groundPlane.transform.position = Vector3.zero;
        // 设置地面大小覆盖整个可放置区域
        groundPlane.transform.localScale = new Vector3((gridSize.x - 1) * cardSpacing / 10f, 1, (gridSize.y - 1) * cardSpacing / 10f);
        
        if (groundMaterial != null)
        {
            groundPlane.GetComponent<Renderer>().material = groundMaterial;
        }
        else
        {
            // 创建默认材质
            Material defaultMaterial = new Material(Shader.Find("Standard"));
            defaultMaterial.color = new Color(0.8f, 0.8f, 0.8f, 0.5f);
            groundPlane.GetComponent<Renderer>().material = defaultMaterial;
        }
    }
    
    void CreateGridLines()
    {
        gridLines = new GameObject("GridLines");
        
        // 创建网格线材质
        Material lineMaterial = new Material(Shader.Find("Standard"));
        lineMaterial.color = Color.gray;
        lineMaterial.SetFloat("_Mode", 3); // Transparent mode
        lineMaterial.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        lineMaterial.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        lineMaterial.SetInt("_ZWrite", 0);
        lineMaterial.DisableKeyword("_ALPHATEST_ON");
        lineMaterial.EnableKeyword("_ALPHABLEND_ON");
        lineMaterial.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        lineMaterial.renderQueue = 3000;
        
        // 创建X方向的网格线
        for (int i = 0; i <= gridSize.x; i++)
        {
            GameObject line = GameObject.CreatePrimitive(PrimitiveType.Cube);
            line.name = $"GridLine_X_{i}";
            line.transform.parent = gridLines.transform;
            line.transform.position = new Vector3(i * cardSpacing - gridSize.x * cardSpacing / 2f, 0.01f, 0);
            line.transform.localScale = new Vector3(0.02f, 0.02f, gridSize.y * cardSpacing);
            line.GetComponent<Renderer>().material = lineMaterial;
        }
        
        // 创建Z方向的网格线
        for (int i = 0; i <= gridSize.y; i++)
        {
            GameObject line = GameObject.CreatePrimitive(PrimitiveType.Cube);
            line.name = $"GridLine_Z_{i}";
            line.transform.parent = gridLines.transform;
            line.transform.position = new Vector3(0, 0.01f, i * cardSpacing - gridSize.y * cardSpacing / 2f);
            line.transform.localScale = new Vector3(gridSize.x * cardSpacing, 0.02f, 0.02f);
            line.GetComponent<Renderer>().material = lineMaterial;
        }
    }
    
    public void SetGridVisible(bool visible)
    {
        if (gridLines != null)
        {
            gridLines.SetActive(visible);
        }
    }
    
    public void UpdateGridSize(Vector2 newSize)
    {
        gridSize = newSize;
        
        // 重新创建地面和网格
        if (groundPlane != null)
        {
            DestroyImmediate(groundPlane);
        }
        if (gridLines != null)
        {
            DestroyImmediate(gridLines);
        }
        
        CreateGroundPlane();
        CreateGridLines();
    }
} 