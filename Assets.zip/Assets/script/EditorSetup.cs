using UnityEngine;
using UnityEditor;

public class EditorSetup : MonoBehaviour
{
    [MenuItem("羊了个羊/快速设置场景")]
    public static void SetupLevelEditorScene()
    {
        // 创建GUI事件管理器
        if (GUIEventManager.Instance == null)
        {
            GameObject guiManager = new GameObject("GUIEventManager");
            guiManager.AddComponent<GUIEventManager>();
            Debug.Log("✅ 创建GUI事件管理器");
        }
        
        // 创建主编辑器对象
        GameObject levelEditor = GameObject.Find("LevelEditor");
        if (levelEditor == null)
        {
            levelEditor = new GameObject("LevelEditor");
            levelEditor.AddComponent<SheepLevelEditor>();
            Debug.Log("✅ 创建LevelEditor对象");
        }
        
        // 设置相机
        Camera mainCamera = Camera.main;
        if (mainCamera == null)
        {
            GameObject cameraObj = new GameObject("Main Camera");
            mainCamera = cameraObj.AddComponent<Camera>();
            cameraObj.tag = "MainCamera";
            Debug.Log("✅ 创建Main Camera");
        }
        
        // 设置相机位置和角度
        mainCamera.transform.position = new Vector3(0, 5, -10);
        mainCamera.transform.rotation = Quaternion.Euler(15, 0, 0);
        mainCamera.fieldOfView = 60f;
        
        // 创建地面平面
        GameObject groundPlane = GameObject.Find("GroundPlane");
        if (groundPlane == null)
        {
            groundPlane = new GameObject("GroundPlane");
            groundPlane.AddComponent<GroundPlane>();
            Debug.Log("✅ 创建GroundPlane对象");
        }
        
        // 创建材质文件夹
        if (!AssetDatabase.IsValidFolder("Assets/Materials"))
        {
            AssetDatabase.CreateFolder("Assets", "Materials");
            Debug.Log("✅ 创建Materials文件夹");
        }
        
        // 创建默认卡片材质
        CreateDefaultCardMaterials();
        
        // 创建Levels文件夹
        if (!AssetDatabase.IsValidFolder("Assets/Levels"))
        {
            AssetDatabase.CreateFolder("Assets", "Levels");
            Debug.Log("✅ 创建Levels文件夹");
        }
        
        // 选择LevelEditor对象
        Selection.activeGameObject = levelEditor;
        
        Debug.Log("🎉 场景设置完成！请检查Inspector中的参数设置。");
    }
    
    [MenuItem("羊了个羊/创建默认材质")]
    public static void CreateDefaultCardMaterials()
    {
        string materialsPath = "Assets/Materials/";
        
        // 定义材质颜色
        Color[] colors = {
            Color.red,      // 类型0
            Color.blue,     // 类型1
            Color.green,    // 类型2
            Color.yellow,   // 类型3
            Color.magenta,  // 类型4
            new Color(1f, 0.5f, 0f), // 橙色 类型5
            Color.cyan,     // 类型6
            new Color(1f, 0.75f, 0.8f) // 粉色 类型7
        };
        
        string[] materialNames = {
            "CardType_0", "CardType_1", "CardType_2", "CardType_3",
            "CardType_4", "CardType_5", "CardType_6", "CardType_7"
        };
        
        for (int i = 0; i < 8; i++)
        {
            string materialPath = materialsPath + materialNames[i] + ".mat";
            
            // 检查材质是否已存在
            Material existingMaterial = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
            if (existingMaterial == null)
            {
                // 创建新材质
                Material newMaterial = new Material(Shader.Find("Standard"));
                newMaterial.color = colors[i];
                newMaterial.name = materialNames[i];
                
                AssetDatabase.CreateAsset(newMaterial, materialPath);
                Debug.Log($"✅ 创建材质: {materialNames[i]}");
            }
        }
        
        AssetDatabase.SaveAssets();
        AssetDatabase.Refresh();
    }
    
    [MenuItem("羊了个羊/设置编辑器参数")]
    public static void SetupEditorParameters()
    {
        GameObject levelEditor = GameObject.Find("LevelEditor");
        if (levelEditor == null)
        {
            Debug.LogError("❌ 找不到LevelEditor对象，请先运行'快速设置场景'");
            return;
        }
        
        SheepLevelEditor editor = levelEditor.GetComponent<SheepLevelEditor>();
        if (editor == null)
        {
            Debug.LogError("❌ LevelEditor对象上没有SheepLevelEditor组件");
            return;
        }
        
        // 设置默认参数
        editor.currentLevelId = 1;
        editor.currentLevelName = "Level_1";
        editor.totalLayers = 3;
        editor.gridSize = new Vector2(8, 8);
        editor.cardSpacing = 1.2f;
        editor.cardSize = 0.8f;
        editor.currentCardType = 0;
        editor.maxCardTypes = 8;
        editor.isEditMode = true;
        editor.showGrid = true;
        editor.selectedLayer = 0;
        
        // 加载材质
        LoadCardMaterials(editor);
        
        Debug.Log("✅ 编辑器参数设置完成");
    }
    
    private static void LoadCardMaterials(SheepLevelEditor editor)
    {
        Material[] materials = new Material[8];
        for (int i = 0; i < 8; i++)
        {
            string materialPath = $"Assets/Materials/CardType_{i}.mat";
            materials[i] = AssetDatabase.LoadAssetAtPath<Material>(materialPath);
        }
        
        editor.cardMaterials = materials;
        Debug.Log("✅ 卡片材质加载完成");
    }
    
    [MenuItem("羊了个羊/创建示例关卡")]
    public static void CreateExampleLevel()
    {
        // 确保Levels文件夹存在
        if (!AssetDatabase.IsValidFolder("Assets/Levels"))
        {
            AssetDatabase.CreateFolder("Assets", "Levels");
        }
        
        // 创建示例关卡文件
        string exampleLevelPath = "Assets/Levels/Level_1_Example.json";
        
        // 检查是否已存在
        if (!System.IO.File.Exists(exampleLevelPath))
        {
            Debug.Log("✅ 示例关卡文件已存在");
            return;
        }
        
        // 这里可以创建更简单的示例关卡
        string simpleLevel = @"{
  ""levelName"": ""Simple_Level"",
  ""levelId"": 1,
  ""totalLayers"": 2,
  ""gridSize"": {""x"": 6, ""y"": 6},
  ""cardSpacing"": 1.2,
  ""cards"": [
    {""id"": 1, ""type"": 0, ""position"": {""x"": -1.2, ""y"": 0.1, ""z"": -1.2}, ""layer"": 1, ""isVisible"": true, ""blockingCards"": []},
    {""id"": 2, ""type"": 0, ""position"": {""x"": 0.0, ""y"": 0.1, ""z"": -1.2}, ""layer"": 1, ""isVisible"": true, ""blockingCards"": []},
    {""id"": 3, ""type"": 0, ""position"": {""x"": 1.2, ""y"": 0.1, ""z"": -1.2}, ""layer"": 1, ""isVisible"": true, ""blockingCards"": []},
    {""id"": 4, ""type"": 1, ""position"": {""x"": -1.2, ""y"": 0.0, ""z"": 0.0}, ""layer"": 0, ""isVisible"": true, ""blockingCards"": [1]},
    {""id"": 5, ""type"": 1, ""position"": {""x"": 0.0, ""y"": 0.0, ""z"": 0.0}, ""layer"": 0, ""isVisible"": true, ""blockingCards"": [2]},
    {""id"": 6, ""type"": 1, ""position"": {""x"": 1.2, ""y"": 0.0, ""z"": 0.0}, ""layer"": 0, ""isVisible"": true, ""blockingCards"": [3]}
  ]
}";
        
        System.IO.File.WriteAllText(exampleLevelPath, simpleLevel);
        AssetDatabase.Refresh();
        Debug.Log("✅ 创建简单示例关卡");
    }
    
    [MenuItem("羊了个羊/完整设置向导")]
    public static void CompleteSetupWizard()
    {
        Debug.Log("🚀 开始羊了个羊关卡编辑器完整设置...");
        
        SetupLevelEditorScene();
        CreateDefaultCardMaterials();
        SetupEditorParameters();
        CreateExampleLevel();
        
        Debug.Log("🎉 完整设置完成！现在可以开始使用关卡编辑器了。");
        Debug.Log("📖 请查看Assets/script/README.md了解详细使用方法。");
    }
} 