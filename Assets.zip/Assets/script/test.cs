using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;
using System;

[System.Serializable]
public class CardData
{
    public int id;
    public int type; // 卡片类型
    public Vector3 position; // 卡片位置
    public int layer; // 层级
    public bool isVisible; // 是否可见
    public List<int> blockingCards; // 阻挡此卡片的卡片ID列表
}

[System.Serializable]
public class LevelData
{
    public string levelName;
    public int levelId;
    public List<CardData> cards;
    public int totalLayers;
    public Vector2 gridSize;
    public float cardSpacing;
    public float cardSize;
}

public class SheepLevelEditor : MonoBehaviour
{
    [Header("编辑器设置")]
    public int currentLevelId = 1;
    public string currentLevelName = "Level_1";
    public int totalLayers = 3;
    public Vector2 gridSize = new Vector2(8, 8);
    public float cardSpacing = 1.2f;
    public float cardSize = 0.8f;
    
    [Header("卡片设置")]
    public GameObject cardPrefab;
    public Material[] cardMaterials;
    public int currentCardType = 0;
    public int maxCardTypes = 8;
    
    [Header("编辑器状态")]
    public bool isEditMode = true;
    public bool showGrid = true;
    public int selectedLayer = 0;
    
    [Header("地面设置")]
    public GroundPlane groundPlane;
    
    [Header("层级遮罩设置")]
    public bool showLayerMasks = true;
    public Color layerMaskColor = new Color(0.5f, 0.5f, 0.5f, 0.3f);
    public float layerMaskHeight = 0.1f;
    
    [Header("可放置区域可视化")]
    public bool showPlaceableArea = true;
    public PlaceableAreaVisualizer placeableAreaVisualizer;
    
    private List<CardData> levelCards = new List<CardData>();
    private List<GameObject> cardObjects = new List<GameObject>();
    private List<GameObject> layerMaskObjects = new List<GameObject>();
    public Camera editorCamera;
    private Vector3 lastMousePosition;
    
    void Start()
    {
        editorCamera = Camera.main;
        if (editorCamera == null)
        {
            GameObject cameraObj = new GameObject("EditorCamera");
            editorCamera = cameraObj.AddComponent<Camera>();
            cameraObj.transform.position = new Vector3(0, 5, -10);
            cameraObj.transform.LookAt(Vector3.zero);
        }
        
        // 创建地面平面
        if (groundPlane == null)
        {
            GameObject groundObj = new GameObject("GroundPlane");
            groundPlane = groundObj.AddComponent<GroundPlane>();
            groundPlane.gridSize = gridSize;
            groundPlane.cardSpacing = cardSpacing;
        }
        
        CreateLayerMasks();
        SetupPlaceableAreaVisualizer();
        LoadLevel(currentLevelId);
        UpdateCardDisplay();
        
        // 确保GUI事件管理器存在
        if (GUIEventManager.Instance != null)
        {
            GUIEventManager.Instance.SetGUIRect(new Rect(10, 10, 300, Screen.height - 20));
        }
    }
    
    void Update()
    {
        if (!isEditMode) return;
        
        HandleInput();
        HandleCameraMovement();
    }
    
    void HandleInput()
    {
        // 多重检查鼠标是否在GUI区域内
        bool isOverGUI = false;
        
        // 主要检查：使用GUI事件管理器
        if (GUIEventManager.Instance != null)
        {
            isOverGUI = GUIEventManager.Instance.IsMouseOverGUI();
            
            // 如果GUI事件管理器说不在GUI上，但我们在GUI区域内，强制检查
            if (!isOverGUI)
            {
                isOverGUI = GUIEventManager.Instance.IsMouseOverGUINow();
            }
        }
        
        // 备用检查方法
        if (!isOverGUI)
        {
            Vector2 mousePos = Input.mousePosition;
            Rect guiRect = new Rect(10, 10, 300, Screen.height - 20);
            isOverGUI = guiRect.Contains(mousePos);
        }
        
        // 最终检查：如果鼠标在屏幕左侧300像素内，认为在GUI上
        if (!isOverGUI && Input.mousePosition.x < 320)
        {
            isOverGUI = true;
        }
        
        if (isOverGUI)
        {
            Debug.Log($"鼠标在GUI区域内，忽略游戏输入 - 位置: {Input.mousePosition}");
            return; // 如果鼠标在GUI上，不处理游戏输入
        }
        
        // 鼠标左键放置卡片
        if (Input.GetMouseButtonDown(0))
        {
            Debug.Log("处理左键点击 - 放置卡片");
            PlaceCard();
        }
        
        // 鼠标右键删除卡片
        if (Input.GetMouseButtonDown(1))
        {
            Debug.Log("处理右键点击 - 删除卡片");
            DeleteCard();
        }
        
        // 滚轮切换层级
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            selectedLayer = Mathf.Clamp(selectedLayer + (scroll > 0 ? 1 : -1), 0, totalLayers - 1);
            UpdateCardDisplay();
        }
        
        // 数字键切换卡片类型
        for (int i = 0; i < maxCardTypes && i < 9; i++)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
            {
                currentCardType = i;
            }
        }
        
        // 快捷键
        if (Input.GetKey(KeyCode.LeftControl))
        {
            if (Input.GetKeyDown(KeyCode.S))
            {
                SaveLevel();
            }
            if (Input.GetKeyDown(KeyCode.L))
            {
                LoadLevel(currentLevelId);
            }
            if (Input.GetKeyDown(KeyCode.N))
            {
                NewLevel();
            }
        }
    }
    
    void HandleCameraMovement()
    {
        // 鼠标中键拖拽移动相机
        if (Input.GetMouseButton(2))
        {
            Vector3 delta = Input.mousePosition - lastMousePosition;
            editorCamera.transform.Translate(-delta.x * 0.01f, -delta.y * 0.01f, 0);
        }
        
        // 滚轮缩放
        float scroll = Input.GetAxis("Mouse ScrollWheel");
        if (scroll != 0)
        {
            editorCamera.transform.Translate(0, 0, scroll * 2f);
        }
        
        lastMousePosition = Input.mousePosition;
    }
    
    bool IsMouseOverGUI()
    {
        // 使用GUI事件管理器检查
        if (GUIEventManager.Instance != null)
        {
            return GUIEventManager.Instance.IsMouseOverGUI();
        }
        
        // 备用检查方法
        Vector2 mousePos = Input.mousePosition;
        Rect guiRect = new Rect(10, 10, 300, Screen.height - 20);
        return guiRect.Contains(mousePos);
    }
    
    void PlaceCard()
    {
        Ray ray = editorCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        
        Vector3 worldPos;
        
        // 尝试射线检测，如果击中物体则使用击中点，否则使用平面投影
        if (Physics.Raycast(ray, out hit))
        {
            worldPos = hit.point;
        }
        else
        {
            // 如果没有击中物体，使用平面投影
            Plane plane = new Plane(Vector3.up, Vector3.zero);
            float distance;
            if (plane.Raycast(ray, out distance))
            {
                worldPos = ray.GetPoint(distance);
            }
            else
            {
                // 如果平面投影也失败，使用默认位置
                worldPos = editorCamera.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, 10f));
            }
        }
        
        Vector3 gridPos = SnapToGrid(worldPos);
        gridPos.y = selectedLayer * 0.1f; // 层级高度
        
        Debug.Log($"尝试放置3D卡片: 世界坐标={worldPos}, 网格坐标={gridPos}");
        
        // 检查位置是否在网格范围内
        if (!IsPositionInGridBounds(gridPos))
        {
            Debug.Log($"位置超出网格范围: {gridPos}");
            return;
        }
        
        // 检查位置是否已有卡片
        if (!IsPositionOccupied(gridPos))
        {
            CardData newCard = new CardData
            {
                id = GetNextCardId(),
                type = currentCardType,
                position = gridPos,
                layer = selectedLayer,
                isVisible = true,
                blockingCards = new List<int>()
            };
            
            levelCards.Add(newCard);
            CreateCardObject(newCard);
            Debug.Log($"成功放置3D卡片: ID={newCard.id}, 位置={gridPos}, 类型={currentCardType}, 层级={selectedLayer}");
        }
        else
        {
            Debug.Log($"位置已被占用: {gridPos}");
        }
    }
    
    void DeleteCard()
    {
        Ray ray = editorCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit hit;
        
        if (Physics.Raycast(ray, out hit))
        {
            GameObject hitObject = hit.collider.gameObject;
            CardData cardToDelete = levelCards.Find(c => c.id == hitObject.GetComponent<CardObject>()?.cardId);
            
            if (cardToDelete != null)
            {
                levelCards.Remove(cardToDelete);
                Destroy(hitObject);
                cardObjects.Remove(hitObject);
            }
        }
    }
    
    Vector3 SnapToGrid(Vector3 worldPos)
    {
        float x = Mathf.Round(worldPos.x / cardSpacing) * cardSpacing;
        float z = Mathf.Round(worldPos.z / cardSpacing) * cardSpacing;
        return new Vector3(x, worldPos.y, z);
    }
    
    bool IsPositionOccupied(Vector3 position)
    {
        // 只检查同一层级的卡片是否占用位置
        return levelCards.Exists(c => c.layer == selectedLayer && Vector3.Distance(c.position, position) < 0.1f);
    }
    
    bool IsPositionInGridBounds(Vector3 position)
    {
        // 计算网格边界
        float halfGridWidth = (gridSize.x - 1) * cardSpacing * 0.5f;
        float halfGridHeight = (gridSize.y - 1) * cardSpacing * 0.5f;
        
        // 检查位置是否在网格范围内（只检查X和Z轴，Y轴是层级高度）
        bool inBounds = Mathf.Abs(position.x) <= halfGridWidth && Mathf.Abs(position.z) <= halfGridHeight;
        
        Debug.Log($"3D网格边界检查: 位置={position}, 网格大小={gridSize}, 卡片间距={cardSpacing}, 边界范围=±({halfGridWidth}, {halfGridHeight}), 在范围内={inBounds}");
        
        return inBounds;
    }
    
    int GetNextCardId()
    {
        int maxId = 0;
        foreach (var card in levelCards)
        {
            maxId = Mathf.Max(maxId, card.id);
        }
        return maxId + 1;
    }
    
    void CreateCardObject(CardData cardData)
    {
        if (cardPrefab == null)
        {
            // 创建默认卡片
            GameObject cardObj = GameObject.CreatePrimitive(PrimitiveType.Cube);
            cardObj.name = $"Card_{cardData.id}";
            cardObj.transform.position = cardData.position;
            cardObj.transform.localScale = Vector3.one * cardSize;
            
            CardObject cardComponent = cardObj.AddComponent<CardObject>();
            cardComponent.cardId = cardData.id;
            cardComponent.cardType = cardData.type;
            cardComponent.layer = cardData.layer;
            cardComponent.baseCardSize = cardSize; // 设置基础卡片大小
            
            // 设置材质
            if (cardMaterials != null && cardData.type < cardMaterials.Length)
            {
                cardObj.GetComponent<Renderer>().material = cardMaterials[cardData.type];
            }
            
            cardObjects.Add(cardObj);
        }
        else
        {
            GameObject cardObj = Instantiate(cardPrefab, cardData.position, Quaternion.identity);
            cardObj.name = $"Card_{cardData.id}";
            
            CardObject cardComponent = cardObj.GetComponent<CardObject>();
            if (cardComponent == null)
            {
                cardComponent = cardObj.AddComponent<CardObject>();
            }
            cardComponent.cardId = cardData.id;
            cardComponent.cardType = cardData.type;
            cardComponent.layer = cardData.layer;
            
            cardObjects.Add(cardObj);
        }
    }
    
    public void UpdateCardDisplay()
    {
        foreach (var cardObj in cardObjects)
        {
            CardObject cardComponent = cardObj.GetComponent<CardObject>();
            if (cardComponent != null)
            {
                // 只显示当前层级的卡片
                cardObj.SetActive(cardComponent.layer == selectedLayer);
            }
        }
        
        // 更新层级遮罩
        UpdateLayerMasks();
    }
    
    void CreateLayerMasks()
    {
        // 清除现有的层级遮罩
        ClearLayerMasks();
        
        if (!showLayerMasks) return;
        
        // 为每个层级创建遮罩
        for (int layer = 0; layer < totalLayers; layer++)
        {
            CreateLayerMask(layer);
        }
    }
    
    void CreateLayerMask(int layer)
    {
        GameObject maskObj = new GameObject($"LayerMask_{layer}");
        maskObj.transform.position = new Vector3(0, layer * layerMaskHeight, 0);
        
        // 创建遮罩平面
        MeshFilter meshFilter = maskObj.AddComponent<MeshFilter>();
        MeshRenderer meshRenderer = maskObj.AddComponent<MeshRenderer>();
        
        // 创建平面网格
        Mesh mesh = CreatePlaneMesh();
        meshFilter.mesh = mesh;
        
        // 创建遮罩材质
        Material maskMaterial = new Material(Shader.Find("Standard"));
        maskMaterial.color = layerMaskColor;
        maskMaterial.SetFloat("_Mode", 3); // 透明模式
        maskMaterial.SetInt("_SrcBlend", (int)UnityEngine.Rendering.BlendMode.SrcAlpha);
        maskMaterial.SetInt("_DstBlend", (int)UnityEngine.Rendering.BlendMode.OneMinusSrcAlpha);
        maskMaterial.SetInt("_ZWrite", 0);
        maskMaterial.DisableKeyword("_ALPHATEST_ON");
        maskMaterial.EnableKeyword("_ALPHABLEND_ON");
        maskMaterial.DisableKeyword("_ALPHAPREMULTIPLY_ON");
        maskMaterial.renderQueue = 3000;
        
        meshRenderer.material = maskMaterial;
        
        // 设置遮罩大小覆盖整个可放置区域
        float maskWidth = (gridSize.x - 1) * cardSpacing;
        float maskHeight = (gridSize.y - 1) * cardSpacing;
        maskObj.transform.localScale = new Vector3(maskWidth, 1, maskHeight);
        
        layerMaskObjects.Add(maskObj);
    }
    
    Mesh CreatePlaneMesh()
    {
        Mesh mesh = new Mesh();
        
        Vector3[] vertices = new Vector3[]
        {
            new Vector3(-0.5f, 0, -0.5f),
            new Vector3(0.5f, 0, -0.5f),
            new Vector3(0.5f, 0, 0.5f),
            new Vector3(-0.5f, 0, 0.5f)
        };
        
        int[] triangles = new int[]
        {
            0, 1, 2,
            0, 2, 3
        };
        
        Vector2[] uvs = new Vector2[]
        {
            new Vector2(0, 0),
            new Vector2(1, 0),
            new Vector2(1, 1),
            new Vector2(0, 1)
        };
        
        mesh.vertices = vertices;
        mesh.triangles = triangles;
        mesh.uv = uvs;
        mesh.RecalculateNormals();
        
        return mesh;
    }
    
    void ClearLayerMasks()
    {
        foreach (GameObject maskObj in layerMaskObjects)
        {
            if (maskObj != null)
            {
                DestroyImmediate(maskObj);
            }
        }
        layerMaskObjects.Clear();
    }
    
    void SetupPlaceableAreaVisualizer()
    {
        // 查找或创建可放置区域可视化组件
        placeableAreaVisualizer = FindObjectOfType<PlaceableAreaVisualizer>();
        if (placeableAreaVisualizer == null)
        {
            GameObject visualizerObj = new GameObject("PlaceableAreaVisualizer");
            placeableAreaVisualizer = visualizerObj.AddComponent<PlaceableAreaVisualizer>();
        }
        
        // 设置可视化状态
        if (placeableAreaVisualizer != null)
        {
            placeableAreaVisualizer.SetVisible(showPlaceableArea);
        }
    }
    
    void UpdateLayerMasks()
    {
        // 更新层级遮罩的显示状态
        for (int i = 0; i < layerMaskObjects.Count; i++)
        {
            if (layerMaskObjects[i] != null)
            {
                MeshRenderer maskRenderer = layerMaskObjects[i].GetComponent<MeshRenderer>();
                if (maskRenderer != null)
                {
                    // 当前编辑层级不显示遮罩，其他层级显示遮罩
                    bool shouldShow = showLayerMasks && i != selectedLayer;
                    maskRenderer.enabled = shouldShow;
                }
            }
        }
    }
    
    void UpdateLayerMaskSizes()
    {
        // 更新所有层级遮罩的大小以匹配可放置区域
        float maskWidth = (gridSize.x - 1) * cardSpacing;
        float maskHeight = (gridSize.y - 1) * cardSpacing;
        
        foreach (GameObject maskObj in layerMaskObjects)
        {
            if (maskObj != null)
            {
                maskObj.transform.localScale = new Vector3(maskWidth, 1, maskHeight);
            }
        }
        
        Debug.Log($"3D层级遮罩大小已更新: {maskWidth} x {maskHeight}");
    }
    
    public void UpdateGridAndMasks()
    {
        // 更新地面网格大小
        if (groundPlane != null)
        {
            groundPlane.gridSize = gridSize;
            groundPlane.cardSpacing = cardSpacing;
            groundPlane.UpdateGridSize(gridSize);
        }
        
        // 更新层级遮罩大小
        UpdateLayerMaskSizes();
        
        // 更新可放置区域可视化
        if (placeableAreaVisualizer != null)
        {
            placeableAreaVisualizer.SetVisible(showPlaceableArea);
        }
        
        float gridWidth = (gridSize.x - 1) * cardSpacing;
        float gridHeight = (gridSize.y - 1) * cardSpacing;
        Debug.Log($"3D网格和遮罩已更新: 网格大小={gridSize}, 间距={cardSpacing}, 可放置区域={gridWidth} x {gridHeight}");
    }
    
    public void UpdateAllCardSizes()
    {
        // 更新所有现有卡片的大小
        foreach (var cardObj in cardObjects)
        {
            cardObj.transform.localScale = Vector3.one * cardSize;
            
            // 同时更新CardObject组件的基础卡片大小
            CardObject cardComponent = cardObj.GetComponent<CardObject>();
            if (cardComponent != null)
            {
                cardComponent.baseCardSize = cardSize;
            }
        }
        
        // 更新层级遮罩大小以匹配网格
        UpdateLayerMaskSizes();
        
        Debug.Log($"卡片大小已更新为: {cardSize}");
    }
    
    void SaveLevel()
    {
        LevelData levelData = new LevelData
        {
            levelName = currentLevelName,
            levelId = currentLevelId,
            cards = new List<CardData>(levelCards),
            totalLayers = totalLayers,
            gridSize = gridSize,
            cardSpacing = cardSpacing,
            cardSize = cardSize
        };
        
        string json = JsonUtility.ToJson(levelData, true);
        string filePath = Path.Combine(Application.dataPath, "Levels", $"Level_{currentLevelId}.json");
        
        // 确保目录存在
        Directory.CreateDirectory(Path.GetDirectoryName(filePath));
        
        File.WriteAllText(filePath, json);
        Debug.Log($"关卡已保存: {filePath}");
    }
    
    public void LoadLevel(int levelId)
    {
        Debug.Log($"尝试加载3D关卡: {levelId}");
        string filePath = Path.Combine(Application.dataPath, "Levels", $"Level_{levelId}.json");
        
        if (File.Exists(filePath))
        {
            string json = File.ReadAllText(filePath);
            LevelData levelData = JsonUtility.FromJson<LevelData>(json);
            
            // 确保关卡ID同步
            currentLevelId = levelData.levelId;
            currentLevelName = levelData.levelName;
            totalLayers = levelData.totalLayers;
            gridSize = levelData.gridSize;
            cardSpacing = levelData.cardSpacing;
            
            // 加载卡片大小，如果没有则使用默认值
            if (levelData.cardSize > 0)
            {
                cardSize = levelData.cardSize;
            }
            
            levelCards = new List<CardData>(levelData.cards);
            
            // 清除现有卡片对象
            foreach (var cardObj in cardObjects)
            {
                Destroy(cardObj);
            }
            cardObjects.Clear();
            
            // 重新创建卡片对象
            foreach (var cardData in levelCards)
            {
                CreateCardObject(cardData);
            }
            
            UpdateCardDisplay();
            UpdateAllCardSizes(); // 确保使用正确的卡片大小
            Debug.Log($"3D关卡已加载: 关卡ID={currentLevelId}, 关卡名称={currentLevelName}, 文件路径={filePath}");
        }
        else
        {
            Debug.Log($"3D关卡文件不存在: {filePath}，创建新关卡");
            NewLevel();
        }
    }
    
    void NewLevel()
    {
        levelCards.Clear();
        foreach (var cardObj in cardObjects)
        {
            Destroy(cardObj);
        }
        cardObjects.Clear();
        
        currentLevelName = $"Level_{currentLevelId}";
        Debug.Log("新建关卡");
    }
    
    void ValidateCurrentLevel()
    {
        LevelData currentLevel = new LevelData
        {
            levelName = currentLevelName,
            levelId = currentLevelId,
            cards = new List<CardData>(levelCards),
            totalLayers = totalLayers,
            gridSize = gridSize,
            cardSpacing = cardSpacing
        };
        
        LevelValidator.ValidationResult result = LevelValidator.ValidateLevel(currentLevel);
        string report = LevelValidator.GetValidationReport(result);
        
        Debug.Log(report);
        
        // 在控制台显示验证结果
        if (result.isValid)
        {
            Debug.Log("✅ 关卡验证通过！");
        }
        else
        {
            Debug.LogError("❌ 关卡验证失败！请检查错误信息。");
        }
    }
    
    void OnGUI()
    {
        if (!isEditMode) return;
        
        // 开始GUI区域
        GUILayout.BeginArea(new Rect(10, 10, 300, Screen.height - 20));
        
        // GUI事件管理器会自动处理事件穿透问题
        GUILayout.BeginVertical("box");
        
        GUILayout.Label("羊了个羊关卡编辑器", GUI.skin.box);
        
        GUILayout.Space(10);
        
        // 关卡信息
        GUILayout.Label("关卡信息");
        int newLevelId = IntField("关卡ID", currentLevelId);
        if (newLevelId != currentLevelId)
        {
            currentLevelId = newLevelId;
            LoadLevel(currentLevelId);
        }
        currentLevelName = TextField("关卡名称", currentLevelName);
        
        GUILayout.Space(10);
        
        // 编辑器设置
        GUILayout.Label("编辑器设置");
        totalLayers = IntField("总层数", totalLayers);
        selectedLayer = IntSlider("当前层级", selectedLayer, 0, totalLayers - 1);
        currentCardType = IntSlider("卡片类型", currentCardType, 0, maxCardTypes - 1);
        
        // 网格设置
        GUILayout.Space(5);
        GUILayout.Label("网格设置");
        
        // 网格大小X
        float newGridSizeX = GUILayout.HorizontalSlider(gridSize.x, 4f, 16f);
        GUILayout.Label($"网格宽度: {newGridSizeX:F0}");
        if (newGridSizeX != gridSize.x)
        {
            gridSize.x = newGridSizeX;
            UpdateGridAndMasks();
        }
        
        // 网格大小Y
        float newGridSizeY = GUILayout.HorizontalSlider(gridSize.y, 4f, 16f);
        GUILayout.Label($"网格高度: {newGridSizeY:F0}");
        if (newGridSizeY != gridSize.y)
        {
            gridSize.y = newGridSizeY;
            UpdateGridAndMasks();
        }
        
        // 卡片间距
        float newCardSpacing = GUILayout.HorizontalSlider(cardSpacing, 0.8f, 2.0f);
        GUILayout.Label($"卡片间距: {newCardSpacing:F2}");
        if (newCardSpacing != cardSpacing)
        {
            cardSpacing = newCardSpacing;
            UpdateGridAndMasks();
        }
        
        // 卡片大小设置
        GUILayout.Space(5);
        GUILayout.Label("卡片设置");
        float newCardSize = GUILayout.HorizontalSlider(cardSize, 0.3f, 2.0f);
        GUILayout.Label($"卡片大小: {newCardSize:F2}");
        if (newCardSize != cardSize)
        {
            cardSize = newCardSize;
            UpdateAllCardSizes();
        }
        
        // 网格设置
        showGrid = GUILayout.Toggle(showGrid, "显示网格");
        if (groundPlane != null)
        {
            groundPlane.SetGridVisible(showGrid);
        }
        
        GUILayout.Space(10);
        
        // 层级遮罩设置
        GUILayout.Label("层级遮罩设置");
        bool newShowLayerMasks = GUILayout.Toggle(showLayerMasks, "显示层级遮罩");
        if (newShowLayerMasks != showLayerMasks)
        {
            showLayerMasks = newShowLayerMasks;
            UpdateLayerMasks();
        }
        
        if (showLayerMasks)
        {
            GUILayout.Label("遮罩透明度");
            float newAlpha = GUILayout.HorizontalSlider(layerMaskColor.a, 0f, 1f);
            if (newAlpha != layerMaskColor.a)
            {
                layerMaskColor.a = newAlpha;
                UpdateLayerMasks();
            }
            GUILayout.Label($"透明度: {newAlpha:F2}");
        }
        
        GUILayout.Space(10);
        
        // 可放置区域可视化设置
        GUILayout.Label("可放置区域可视化");
        bool newShowPlaceableArea = GUILayout.Toggle(showPlaceableArea, "显示可放置区域");
        if (newShowPlaceableArea != showPlaceableArea)
        {
            showPlaceableArea = newShowPlaceableArea;
            if (placeableAreaVisualizer != null)
            {
                placeableAreaVisualizer.SetVisible(showPlaceableArea);
            }
        }
        
        GUILayout.Space(10);
        
        // 操作按钮
        GUILayout.Label("操作");
        GUILayout.BeginHorizontal();
        if (GUILayout.Button("保存关卡"))
        {
            SaveLevel();
        }
        if (GUILayout.Button("加载关卡"))
        {
            LoadLevel(currentLevelId);
        }
        GUILayout.EndHorizontal();
        
        if (GUILayout.Button("新建关卡"))
        {
            NewLevel();
        }
        
        if (GUILayout.Button("验证关卡"))
        {
            ValidateCurrentLevel();
        }
        
        GUILayout.Space(10);
        
        // 统计信息
        GUILayout.Label("统计信息");
        GUILayout.Label($"总卡片数: {levelCards.Count}");
        GUILayout.Label($"当前层级卡片: {levelCards.FindAll(c => c.layer == selectedLayer).Count}");
        
        GUILayout.Space(10);
        
        // 操作说明
        GUILayout.Label("操作说明");
        GUILayout.Label("左键: 放置卡片");
        GUILayout.Label("右键: 删除卡片");
        GUILayout.Label("滚轮: 切换层级");
        GUILayout.Label("数字键1-9: 切换卡片类型");
        GUILayout.Label("Ctrl+S: 保存关卡");
        GUILayout.Label("Ctrl+L: 加载关卡");
        GUILayout.Label("Ctrl+N: 新建关卡");
        
        GUILayout.EndVertical();
        GUILayout.EndArea();
    }

    // 辅助输入方法，放在SheepLevelEditor类内部
    int IntField(string label, int value)
    {
        GUILayout.BeginHorizontal();
        GUILayout.Label(label);
        string text = GUILayout.TextField(value.ToString());
        GUILayout.EndHorizontal();
        int result;
        if (int.TryParse(text, out result))
        {
            return result;
        }
        return value;
    }
    string TextField(string label, string value)
    {
        GUILayout.BeginHorizontal();
        GUILayout.Label(label);
        string result = GUILayout.TextField(value);
        GUILayout.EndHorizontal();
        return result;
    }
    int IntSlider(string label, int value, int min, int max)
    {
        GUILayout.BeginHorizontal();
        GUILayout.Label(label);
        int result = (int)GUILayout.HorizontalSlider(value, min, max);
        GUILayout.Label(result.ToString());
        GUILayout.EndHorizontal();
        return result;
    }
}

// 卡片对象组件
public class CardObject : MonoBehaviour
{
    public int cardId;
    public int cardType;
    public int layer;
    public float baseCardSize = 0.8f; // 基础卡片大小
    
    void OnMouseEnter()
    {
        // 鼠标悬停效果 - 基于基础卡片大小
        transform.localScale = Vector3.one * baseCardSize * 0.9f;
    }
    
    void OnMouseExit()
    {
        // 恢复正常大小 - 基于基础卡片大小
        transform.localScale = Vector3.one * baseCardSize;
    }
}
